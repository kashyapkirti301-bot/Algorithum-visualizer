// Each generator yields a "frame" describing the array state at that step:
// { array, comparing: [i, j] | [], swapping: [i, j] | [], sorted: number[] }
// Consumers step through frames to animate. This keeps the algorithm logic
// pure and decoupled from rendering/timing.

function frame(array, { comparing = [], swapping = [], sorted = [] } = {}) {
  return { array: [...array], comparing, swapping, sorted }
}

export function* bubbleSort(input) {
  const arr = [...input]
  const n = arr.length
  const sorted = []
  for (let i = 0; i < n - 1; i++) {
    let swappedAny = false
    for (let j = 0; j < n - i - 1; j++) {
      yield frame(arr, { comparing: [j, j + 1], sorted })
      if (arr[j] > arr[j + 1]) {
        ;[arr[j], arr[j + 1]] = [arr[j + 1], arr[j]]
        swappedAny = true
        yield frame(arr, { swapping: [j, j + 1], sorted })
      }
    }
    sorted.unshift(n - i - 1)
    if (!swappedAny) break
  }
  yield frame(arr, { sorted: arr.map((_, i) => i) })
}

export function* selectionSort(input) {
  const arr = [...input]
  const n = arr.length
  const sorted = []
  for (let i = 0; i < n; i++) {
    let minIdx = i
    for (let j = i + 1; j < n; j++) {
      yield frame(arr, { comparing: [minIdx, j], sorted })
      if (arr[j] < arr[minIdx]) minIdx = j
    }
    if (minIdx !== i) {
      ;[arr[i], arr[minIdx]] = [arr[minIdx], arr[i]]
      yield frame(arr, { swapping: [i, minIdx], sorted })
    }
    sorted.push(i)
  }
  yield frame(arr, { sorted: arr.map((_, i) => i) })
}

export function* insertionSort(input) {
  const arr = [...input]
  const n = arr.length
  for (let i = 1; i < n; i++) {
    let j = i
    while (j > 0 && arr[j - 1] > arr[j]) {
      yield frame(arr, { comparing: [j - 1, j] })
      ;[arr[j - 1], arr[j]] = [arr[j], arr[j - 1]]
      yield frame(arr, { swapping: [j - 1, j] })
      j--
    }
  }
  yield frame(arr, { sorted: arr.map((_, i) => i) })
}

export function* mergeSort(input) {
  const arr = [...input]

  function* sort(lo, hi) {
    if (hi - lo <= 1) return
    const mid = Math.floor((lo + hi) / 2)
    yield* sort(lo, mid)
    yield* sort(mid, hi)
    const left = arr.slice(lo, mid)
    const right = arr.slice(mid, hi)
    let i = 0,
      j = 0,
      k = lo
    while (i < left.length && j < right.length) {
      yield frame(arr, { comparing: [lo + i, mid + j] })
      if (left[i] <= right[j]) {
        arr[k++] = left[i++]
      } else {
        arr[k++] = right[j++]
      }
      yield frame(arr, { swapping: [k - 1, k - 1] })
    }
    while (i < left.length) arr[k++] = left[i++]
    while (j < right.length) arr[k++] = right[j++]
    yield frame(arr, {})
  }

  yield* sort(0, arr.length)
  yield frame(arr, { sorted: arr.map((_, i) => i) })
}

export function* quickSort(input) {
  const arr = [...input]

  function* sort(lo, hi) {
    if (lo >= hi) return
    const pivot = arr[hi]
    let i = lo
    for (let j = lo; j < hi; j++) {
      yield frame(arr, { comparing: [j, hi] })
      if (arr[j] < pivot) {
        ;[arr[i], arr[j]] = [arr[j], arr[i]]
        yield frame(arr, { swapping: [i, j] })
        i++
      }
    }
    ;[arr[i], arr[hi]] = [arr[hi], arr[i]]
    yield frame(arr, { swapping: [i, hi] })
    yield* sort(lo, i - 1)
    yield* sort(i + 1, hi)
  }

  yield* sort(0, arr.length - 1)
  yield frame(arr, { sorted: arr.map((_, i) => i) })
}

export function* heapSort(input) {
  const arr = [...input]
  const n = arr.length

  function* heapify(size, root) {
    let largest = root
    const l = 2 * root + 1
    const r = 2 * root + 2
    if (l < size) {
      yield frame(arr, { comparing: [l, largest] })
      if (arr[l] > arr[largest]) largest = l
    }
    if (r < size) {
      yield frame(arr, { comparing: [r, largest] })
      if (arr[r] > arr[largest]) largest = r
    }
    if (largest !== root) {
      ;[arr[root], arr[largest]] = [arr[largest], arr[root]]
      yield frame(arr, { swapping: [root, largest] })
      yield* heapify(size, largest)
    }
  }

  for (let i = Math.floor(n / 2) - 1; i >= 0; i--) {
    yield* heapify(n, i)
  }
  const sorted = []
  for (let end = n - 1; end > 0; end--) {
    ;[arr[0], arr[end]] = [arr[end], arr[0]]
    yield frame(arr, { swapping: [0, end], sorted })
    sorted.unshift(end)
    yield* heapify(end, 0)
  }
  yield frame(arr, { sorted: arr.map((_, i) => i) })
}

export const SORT_ALGORITHMS = {
  bubble: { label: 'Bubble Sort', complexity: 'O(n\u00b2) time \u00b7 O(1) space', run: bubbleSort },
  selection: { label: 'Selection Sort', complexity: 'O(n\u00b2) time \u00b7 O(1) space', run: selectionSort },
  insertion: { label: 'Insertion Sort', complexity: 'O(n\u00b2) time \u00b7 O(1) space', run: insertionSort },
  merge: { label: 'Merge Sort', complexity: 'O(n log n) time \u00b7 O(n) space', run: mergeSort },
  quick: { label: 'Quick Sort', complexity: 'O(n log n) avg \u00b7 O(log n) space', run: quickSort },
  heap: { label: 'Heap Sort', complexity: 'O(n log n) time \u00b7 O(1) space', run: heapSort }
}
