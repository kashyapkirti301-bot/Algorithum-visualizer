// Grid algorithms operate on a 2D array of cell types: 0 = open, 1 = wall.
// Each generator yields { visited: {row,col}, frontier: [{row,col}...] } while
// searching, then a final { done: true, path: [{row,col}...], visitedCount }.

function key(r, c) {
  return `${r},${c}`
}

function neighbors(grid, row, col) {
  const dirs = [
    [-1, 0],
    [1, 0],
    [0, -1],
    [0, 1]
  ]
  const out = []
  for (const [dr, dc] of dirs) {
    const r = row + dr
    const c = col + dc
    if (r >= 0 && r < grid.length && c >= 0 && c < grid[0].length && grid[r][c] !== 1) {
      out.push({ row: r, col: c })
    }
  }
  return out
}

function reconstructPath(cameFrom, endKey) {
  const path = []
  let cur = endKey
  while (cur && cameFrom.has(cur)) {
    const [r, c] = cur.split(',').map(Number)
    path.unshift({ row: r, col: c })
    cur = cameFrom.get(cur)
  }
  return path
}

export function* bfs(grid, start, end) {
  const q = [start]
  const cameFrom = new Map()
  const seen = new Set([key(start.row, start.col)])
  let visitedCount = 0

  while (q.length) {
    const current = q.shift()
    visitedCount++
    yield { visited: current, frontier: [...q] }

    if (current.row === end.row && current.col === end.col) {
      yield { done: true, path: reconstructPath(cameFrom, key(end.row, end.col)), visitedCount }
      return
    }

    for (const n of neighbors(grid, current.row, current.col)) {
      const k = key(n.row, n.col)
      if (!seen.has(k)) {
        seen.add(k)
        cameFrom.set(k, key(current.row, current.col))
        q.push(n)
      }
    }
  }
  yield { done: true, path: [], visitedCount }
}

export function* dfs(grid, start, end) {
  const stack = [start]
  const cameFrom = new Map()
  const seen = new Set()
  let visitedCount = 0

  while (stack.length) {
    const current = stack.pop()
    const ck = key(current.row, current.col)
    if (seen.has(ck)) continue
    seen.add(ck)
    visitedCount++
    yield { visited: current, frontier: [...stack] }

    if (current.row === end.row && current.col === end.col) {
      yield { done: true, path: reconstructPath(cameFrom, ck), visitedCount }
      return
    }

    for (const n of neighbors(grid, current.row, current.col)) {
      const k = key(n.row, n.col)
      if (!seen.has(k)) {
        cameFrom.set(k, ck)
        stack.push(n)
      }
    }
  }
  yield { done: true, path: [], visitedCount }
}

export function* dijkstra(grid, start, end) {
  const dist = new Map()
  const cameFrom = new Map()
  const visited = new Set()
  dist.set(key(start.row, start.col), 0)
  let visitedCount = 0

  while (true) {
    let currentKey = null
    let best = Infinity
    for (const [k, d] of dist) {
      if (!visited.has(k) && d < best) {
        best = d
        currentKey = k
      }
    }
    if (currentKey === null) break

    const [row, col] = currentKey.split(',').map(Number)
    visited.add(currentKey)
    visitedCount++
    yield { visited: { row, col }, frontier: [] }

    if (row === end.row && col === end.col) {
      yield { done: true, path: reconstructPath(cameFrom, currentKey), visitedCount }
      return
    }

    for (const n of neighbors(grid, row, col)) {
      const nk = key(n.row, n.col)
      const newDist = best + 1
      if (newDist < (dist.has(nk) ? dist.get(nk) : Infinity)) {
        dist.set(nk, newDist)
        cameFrom.set(nk, currentKey)
      }
    }
  }
  yield { done: true, path: [], visitedCount }
}

function heuristic(a, b) {
  return Math.abs(a.row - b.row) + Math.abs(a.col - b.col) // Manhattan distance
}

export function* astar(grid, start, end) {
  const gScore = new Map([[key(start.row, start.col), 0]])
  const fScore = new Map([[key(start.row, start.col), heuristic(start, end)]])
  const cameFrom = new Map()
  const open = new Set([key(start.row, start.col)])
  const closed = new Set()
  let visitedCount = 0

  while (open.size) {
    let currentKey = null
    let best = Infinity
    for (const k of open) {
      const f = fScore.has(k) ? fScore.get(k) : Infinity
      if (f < best) {
        best = f
        currentKey = k
      }
    }
    open.delete(currentKey)
    closed.add(currentKey)
    visitedCount++

    const [row, col] = currentKey.split(',').map(Number)
    yield { visited: { row, col }, frontier: [...open] }

    if (row === end.row && col === end.col) {
      yield { done: true, path: reconstructPath(cameFrom, currentKey), visitedCount }
      return
    }

    for (const n of neighbors(grid, row, col)) {
      const nk = key(n.row, n.col)
      if (closed.has(nk)) continue
      const tentativeG = gScore.get(currentKey) + 1
      if (tentativeG < (gScore.has(nk) ? gScore.get(nk) : Infinity)) {
        cameFrom.set(nk, currentKey)
        gScore.set(nk, tentativeG)
        fScore.set(nk, tentativeG + heuristic(n, end))
        open.add(nk)
      }
    }
  }
  yield { done: true, path: [], visitedCount }
}

export const GRID_ALGORITHMS = {
  bfs: { label: 'Breadth-First Search', complexity: 'O(V + E) \u00b7 unweighted shortest path', run: bfs },
  dfs: { label: 'Depth-First Search', complexity: 'O(V + E) \u00b7 no shortest-path guarantee', run: dfs },
  dijkstra: { label: "Dijkstra's Algorithm", complexity: 'O(V\u00b2) simple impl \u00b7 weighted shortest path', run: dijkstra },
  astar: { label: 'A* Search', complexity: 'O(E) w/ good heuristic \u00b7 weighted shortest path', run: astar }
}
