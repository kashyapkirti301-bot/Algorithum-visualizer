import { useState } from 'react'
import SortingVisualizer from './components/SortingVisualizer'
import GridVisualizer from './components/GridVisualizer'

const TABS = [
  { key: 'sorting', label: 'Sorting' },
  { key: 'grid', label: 'Traversal / Pathfinding' }
]

export default function App() {
  const [tab, setTab] = useState('sorting')

  return (
    <div className="min-h-screen px-6 py-8 md:px-12">
      <header className="mx-auto mb-8 max-w-5xl border-b border-blueprint/50 pb-6">
        <p className="font-mono text-xs uppercase tracking-wide text-blueprintLight">
          fig. 01 — interactive schematic
        </p>
        <h1 className="mt-2 text-3xl font-semibold text-paper md:text-4xl">Algorithm Visualizer</h1>
        <p className="mt-2 max-w-2xl text-sm text-paper/70">
          Step through sorting, graph traversal, and pathfinding algorithms one operation at a time.
          Draw walls, drop a maze, and watch how each algorithm explores the search space differently.
        </p>
        <nav className="mt-6 flex gap-2">
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`rounded-sm px-4 py-2 text-sm font-medium transition ${
                tab === t.key
                  ? 'bg-amber text-ink'
                  : 'border border-blueprintLight text-paper/70 hover:bg-blueprint/40'
              }`}
            >
              {t.label}
            </button>
          ))}
        </nav>
      </header>

      <main className="mx-auto max-w-5xl">
        {tab === 'sorting' ? <SortingVisualizer /> : <GridVisualizer />}
      </main>

      <footer className="mx-auto mt-10 max-w-5xl border-t border-blueprint/50 pt-4 font-mono text-[11px] text-paper/40">
        built with vite + react + canvas — no backend, runs entirely client-side
      </footer>
    </div>
  )
}
