export default function Controls({
  isPlaying,
  onPlayPause,
  onStep,
  onReset,
  onShuffle,
  speed,
  onSpeedChange,
  disabled,
  shuffleLabel = 'New Array'
}) {
  return (
    <div className="flex flex-wrap items-center gap-3 rounded-md border border-blueprint/50 bg-graphite/60 p-3">
      <button
        onClick={onPlayPause}
        disabled={disabled}
        className="rounded-sm bg-amber px-4 py-2 text-sm font-semibold text-ink transition hover:bg-amber/80 disabled:opacity-40"
      >
        {isPlaying ? 'Pause' : 'Play'}
      </button>
      <button
        onClick={onStep}
        disabled={disabled || isPlaying}
        className="rounded-sm border border-blueprintLight px-4 py-2 text-sm text-paper transition hover:bg-blueprint/40 disabled:opacity-40"
      >
        Step
      </button>
      <button
        onClick={onReset}
        className="rounded-sm border border-blueprintLight px-4 py-2 text-sm text-paper transition hover:bg-blueprint/40"
      >
        Reset
      </button>
      {onShuffle && (
        <button
          onClick={onShuffle}
          className="rounded-sm border border-blueprintLight px-4 py-2 text-sm text-paper transition hover:bg-blueprint/40"
        >
          {shuffleLabel}
        </button>
      )}
      <div className="ml-auto flex items-center gap-2 text-sm text-paper/80">
        <label htmlFor="speed" className="font-mono text-xs">
          speed
        </label>
        <input
          id="speed"
          type="range"
          min="1"
          max="100"
          value={speed}
          onChange={(e) => onSpeedChange(Number(e.target.value))}
          className="w-28 accent-amber"
        />
      </div>
    </div>
  )
}
