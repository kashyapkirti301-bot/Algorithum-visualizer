import { useEffect, useRef, useState, useCallback } from 'react'
import { SORT_ALGORITHMS } from '../algorithms/sorting'
import Controls from './Controls'

function randomArray(size) {
  return Array.from({ length: size }, () => Math.floor(Math.random() * 260) + 10)
}

export default function SortingVisualizer() {
  const [algoKey, setAlgoKey] = useState('merge')
  const [size, setSize] = useState(40)
  const [speed, setSpeed] = useState(60)
  const [array, setArray] = useState(() => randomArray(40))
  const [frame, setFrame] = useState({ array, comparing: [], swapping: [], sorted: [] })
  const [isPlaying, setIsPlaying] = useState(false)
  const [stats, setStats] = useState({ comparisons: 0, swaps: 0 })
  const [finished, setFinished] = useState(false)

  const canvasRef = useRef(null)
  const genRef = useRef(null)
  const intervalRef = useRef(null)

  const buildGenerator = useCallback(
    (baseArray) => {
      genRef.current = SORT_ALGORITHMS[algoKey].run(baseArray)
    },
    [algoKey]
  )

  const resetRun = useCallback(
    (newArray) => {
      const base = newArray || array
      setArray(base)
      setFrame({ array: base, comparing: [], swapping: [], sorted: [] })
      setStats({ comparisons: 0, swaps: 0 })
      setFinished(false)
      setIsPlaying(false)
      buildGenerator(base)
    },
    [array, buildGenerator]
  )

  useEffect(() => {
    resetRun(array)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [algoKey])

  useEffect(() => {
    const newArr = randomArray(size)
    resetRun(newArr)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [size])

  const step = useCallback(() => {
    if (!genRef.current) return
    const { value, done } = genRef.current.next()
    if (done) {
      setIsPlaying(false)
      setFinished(true)
      return
    }
    setFrame(value)
    setStats((s) => ({
      comparisons: s.comparisons + (value.comparing.length ? 1 : 0),
      swaps: s.swaps + (value.swapping.length ? 1 : 0)
    }))
    if (value.sorted.length === value.array.length) {
      setFinished(true)
      setIsPlaying(false)
    }
  }, [])

  useEffect(() => {
    if (isPlaying) {
      const delay = Math.max(4, 260 - speed * 2.5)
      intervalRef.current = setInterval(step, delay)
      return () => clearInterval(intervalRef.current)
    }
  }, [isPlaying, speed, step])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    const { width, height } = canvas
    ctx.clearRect(0, 0, width, height)

    const data = frame.array
    const barWidth = width / data.length
    const max = Math.max(...data, 1)

    data.forEach((value, i) => {
      const barHeight = (value / max) * (height - 10)
      let color = '#3F7CB5'
      if (frame.sorted.includes(i)) color = '#4FD1A5'
      else if (frame.swapping.includes(i)) color = '#E85D75'
      else if (frame.comparing.includes(i)) color = '#F2A93B'

      ctx.fillStyle = color
      ctx.fillRect(i * barWidth + 1, height - barHeight, Math.max(barWidth - 2, 1), barHeight)
    })
  }, [frame])

  const algo = SORT_ALGORITHMS[algoKey]

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 className="font-mono text-xs uppercase tracking-wide text-blueprintLight">Module 01</h2>
          <h3 className="text-xl font-semibold text-paper">Sorting Visualizer</h3>
          <p className="mt-1 font-mono text-xs text-paper/60">{algo.complexity}</p>
        </div>
        <div className="flex flex-wrap gap-3">
          <select
            value={algoKey}
            onChange={(e) => setAlgoKey(e.target.value)}
            className="rounded-sm border border-blueprintLight bg-graphite px-3 py-2 text-sm text-paper"
          >
            {Object.entries(SORT_ALGORITHMS).map(([k, v]) => (
              <option key={k} value={k}>
                {v.label}
              </option>
            ))}
          </select>
          <label className="flex items-center gap-2 rounded-sm border border-blueprintLight bg-graphite px-3 py-2 text-sm text-paper/80">
            size
            <input
              type="range"
              min="8"
              max="120"
              value={size}
              onChange={(e) => setSize(Number(e.target.value))}
              className="accent-amber"
            />
            <span className="font-mono text-xs">{size}</span>
          </label>
        </div>
      </div>

      <div className="relative rounded-md border border-blueprint/50 bg-graphite/40 p-3">
        <canvas ref={canvasRef} width={960} height={340} className="w-full" />
        {finished && (
          <div className="absolute right-4 top-4 rounded-sm bg-mint px-3 py-1 text-xs font-semibold text-ink">
            Sorted
          </div>
        )}
      </div>

      <div className="flex flex-wrap items-center gap-6 font-mono text-xs text-paper/70">
        <span>comparisons: {stats.comparisons}</span>
        <span>swaps: {stats.swaps}</span>
        <span>n = {array.length}</span>
      </div>

      <Controls
        isPlaying={isPlaying}
        onPlayPause={() => setIsPlaying((p) => !p)}
        onStep={step}
        onReset={() => resetRun(array)}
        onShuffle={() => resetRun(randomArray(size))}
        speed={speed}
        onSpeedChange={setSpeed}
        disabled={finished}
      />

      <div className="flex gap-4 font-mono text-[11px] text-paper/60">
        <Legend color="#3F7CB5" label="unsorted" />
        <Legend color="#F2A93B" label="comparing" />
        <Legend color="#E85D75" label="swapping" />
        <Legend color="#4FD1A5" label="sorted" />
      </div>
    </div>
  )
}

function Legend({ color, label }) {
  return (
    <span className="flex items-center gap-1.5">
      <span className="inline-block h-2.5 w-2.5 rounded-sm" style={{ backgroundColor: color }} />
      {label}
    </span>
  )
}
