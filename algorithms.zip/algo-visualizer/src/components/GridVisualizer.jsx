import { useEffect, useRef, useState, useCallback } from 'react'
import { GRID_ALGORITHMS } from '../algorithms/pathfinding'
import Controls from './Controls'

const ROWS = 20
const COLS = 34

function emptyGrid() {
  return Array.from({ length: ROWS }, () => Array.from({ length: COLS }, () => 0))
}

function randomWalls(density = 0.22, start, end) {
  const grid = emptyGrid()
  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      const isStart = r === start.row && c === start.col
      const isEnd = r === end.row && c === end.col
      if (!isStart && !isEnd && Math.random() < density) grid[r][c] = 1
    }
  }
  return grid
}

export default function GridVisualizer() {
  const [algoKey, setAlgoKey] = useState('astar')
  const [start] = useState({ row: 10, col: 4 })
  const [end] = useState({ row: 10, col: 29 })
  const [grid, setGrid] = useState(() => emptyGrid())
  const [visited, setVisited] = useState([])
  const [path, setPath] = useState([])
  const [isPlaying, setIsPlaying] = useState(false)
  const [finished, setFinished] = useState(false)
  const [speed, setSpeed] = useState(70)
  const [mode, setMode] = useState('wall') // 'wall' | 'erase'
  const [visitedCount, setVisitedCount] = useState(0)

  const canvasRef = useRef(null)
  const genRef = useRef(null)
  const intervalRef = useRef(null)
  const isDrawing = useRef(false)

  const cellSize = 24

  const buildGenerator = useCallback(
    (g) => {
      genRef.current = GRID_ALGORITHMS[algoKey].run(g, start, end)
    },
    [algoKey, start, end]
  )

  const resetRun = useCallback(
    (g) => {
      const base = g || grid
      setGrid(base)
      setVisited([])
      setPath([])
      setFinished(false)
      setIsPlaying(false)
      setVisitedCount(0)
      buildGenerator(base)
    },
    [grid, buildGenerator]
  )

  useEffect(() => {
    resetRun(grid)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [algoKey])

  const step = useCallback(() => {
    if (!genRef.current) return
    const { value, done } = genRef.current.next()
    if (done) {
      setIsPlaying(false)
      return
    }
    if (value.done) {
      setPath(value.path)
      setVisitedCount(value.visitedCount)
      setFinished(true)
      setIsPlaying(false)
      return
    }
    setVisited((v) => [...v, value.visited])
  }, [])

  useEffect(() => {
    if (isPlaying) {
      const delay = Math.max(2, 120 - speed)
      intervalRef.current = setInterval(step, delay)
      return () => clearInterval(intervalRef.current)
    }
  }, [isPlaying, speed, step])

  const paintCell = (row, col, value) => {
    if ((row === start.row && col === start.col) || (row === end.row && col === end.col)) return
    setGrid((g) => {
      const copy = g.map((r) => [...r])
      copy[row][col] = value
      return copy
    })
  }

  const cellFromEvent = (e) => {
    const rect = canvasRef.current.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top
    return { row: Math.floor(y / cellSize), col: Math.floor(x / cellSize) }
  }

  const handlePointerDown = (e) => {
    if (isPlaying) return
    isDrawing.current = true
    const { row, col } = cellFromEvent(e)
    if (row >= 0 && row < ROWS && col >= 0 && col < COLS) {
      paintCell(row, col, mode === 'wall' ? 1 : 0)
    }
  }
  const handlePointerMove = (e) => {
    if (!isDrawing.current || isPlaying) return
    const { row, col } = cellFromEvent(e)
    if (row >= 0 && row < ROWS && col >= 0 && col < COLS) {
      paintCell(row, col, mode === 'wall' ? 1 : 0)
    }
  }
  const handlePointerUp = () => {
    isDrawing.current = false
  }

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    const visitedSet = new Set(visited.map((v) => `${v.row},${v.col}`))
    const pathSet = new Set(path.map((v) => `${v.row},${v.col}`))

    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        let color = '#12294B'
        if (grid[r][c] === 1) color = '#0B1F3A'
        if (visitedSet.has(`${r},${c}`)) color = 'rgba(242,169,59,0.35)'
        if (pathSet.has(`${r},${c}`)) color = '#4FD1A5'
        if (r === start.row && c === start.col) color = '#E85D75'
        if (r === end.row && c === end.col) color = '#3F7CB5'

        ctx.fillStyle = color
        ctx.fillRect(c * cellSize + 1, r * cellSize + 1, cellSize - 2, cellSize - 2)

        if (grid[r][c] === 1) {
          ctx.strokeStyle = 'rgba(46,92,138,0.6)'
          ctx.strokeRect(c * cellSize + 1, r * cellSize + 1, cellSize - 2, cellSize - 2)
        }
      }
    }
  }, [grid, visited, path, start, end])

  const algo = GRID_ALGORITHMS[algoKey]

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 className="font-mono text-xs uppercase tracking-wide text-blueprintLight">Module 02</h2>
          <h3 className="text-xl font-semibold text-paper">Traversal &amp; Pathfinding</h3>
          <p className="mt-1 font-mono text-xs text-paper/60">{algo.complexity}</p>
        </div>
        <div className="flex flex-wrap gap-3">
          <select
            value={algoKey}
            onChange={(e) => setAlgoKey(e.target.value)}
            className="rounded-sm border border-blueprintLight bg-graphite px-3 py-2 text-sm text-paper"
          >
            {Object.entries(GRID_ALGORITHMS).map(([k, v]) => (
              <option key={k} value={k}>
                {v.label}
              </option>
            ))}
          </select>
          <div className="flex rounded-sm border border-blueprintLight bg-graphite text-sm">
            <button
              onClick={() => setMode('wall')}
              className={`px-3 py-2 ${mode === 'wall' ? 'bg-blueprint text-paper' : 'text-paper/60'}`}
            >
              Draw walls
            </button>
            <button
              onClick={() => setMode('erase')}
              className={`px-3 py-2 ${mode === 'erase' ? 'bg-blueprint text-paper' : 'text-paper/60'}`}
            >
              Erase
            </button>
          </div>
        </div>
      </div>

      <div className="overflow-x-auto rounded-md border border-blueprint/50 bg-graphite/40 p-3">
        <canvas
          ref={canvasRef}
          width={COLS * cellSize}
          height={ROWS * cellSize}
          className="cursor-crosshair"
          onMouseDown={handlePointerDown}
          onMouseMove={handlePointerMove}
          onMouseUp={handlePointerUp}
          onMouseLeave={handlePointerUp}
        />
      </div>

      <div className="flex flex-wrap items-center gap-6 font-mono text-xs text-paper/70">
        <span>visited: {visitedCount || visited.length}</span>
        <span>path length: {path.length}</span>
        <span>
          {finished ? (path.length ? 'path found' : 'no path — blocked by walls') : 'ready'}
        </span>
      </div>

      <Controls
        isPlaying={isPlaying}
        onPlayPause={() => setIsPlaying((p) => !p)}
        onStep={step}
        onReset={() => resetRun(grid)}
        onShuffle={() => resetRun(randomWalls(0.22, start, end))}
        shuffleLabel="Random Maze"
        speed={speed}
        onSpeedChange={setSpeed}
        disabled={finished}
      />

      <div className="flex flex-wrap gap-4 font-mono text-[11px] text-paper/60">
        <Legend color="#E85D75" label="start" />
        <Legend color="#3F7CB5" label="end" />
        <Legend color="#0B1F3A" label="wall" outline />
        <Legend color="rgba(242,169,59,0.6)" label="visited" />
        <Legend color="#4FD1A5" label="shortest path" />
      </div>
    </div>
  )
}

function Legend({ color, label, outline }) {
  return (
    <span className="flex items-center gap-1.5">
      <span
        className="inline-block h-2.5 w-2.5 rounded-sm"
        style={{ backgroundColor: color, border: outline ? '1px solid #2E5C8A' : 'none' }}
      />
      {label}
    </span>
  )
}
