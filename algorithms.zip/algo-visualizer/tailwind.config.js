/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#0B1F3A',
        blueprint: '#2E5C8A',
        blueprintLight: '#3F7CB5',
        paper: '#EDF2F7',
        amber: '#F2A93B',
        mint: '#4FD1A5',
        coral: '#E85D75',
        graphite: '#12294B'
      },
      fontFamily: {
        mono: ['IBM Plex Mono', 'ui-monospace', 'monospace'],
        sans: ['IBM Plex Sans', 'ui-sans-serif', 'system-ui']
      },
      backgroundImage: {
        blueprintGrid:
          'linear-gradient(rgba(63,124,181,0.18) 1px, transparent 1px), linear-gradient(90deg, rgba(63,124,181,0.18) 1px, transparent 1px)'
      },
      backgroundSize: {
        grid: '28px 28px'
      }
    }
  },
  plugins: []
}
