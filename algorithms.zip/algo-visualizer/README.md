# Algorithm Visualizer

Interactive, step-by-step visualizer for sorting algorithms, graph traversal
(BFS/DFS), and pathfinding (Dijkstra, A*). Pure client-side app — no backend,
runs entirely in the browser.

## Stack

- **React 18** + **Vite** — fast dev server, tiny production bundle
- **Tailwind CSS** — utility styling, no runtime CSS-in-JS overhead
- **HTML Canvas API** — array bars and grid cells are drawn on canvas instead
  of hundreds of DOM nodes, so animation stays smooth even on low-power
  hardware (tested target: dual/quad-core laptops with 4–8GB RAM)

## Features

**Sorting Visualizer**
- Bubble, Selection, Insertion, Merge, Quick, and Heap sort
- Play / pause / step-through / reset, adjustable array size and speed
- Live comparison and swap counters

**Traversal & Pathfinding Visualizer**
- BFS, DFS, Dijkstra, and A* (Manhattan-distance heuristic) on a 34×20 grid
- Click-and-drag to draw walls, or generate a random maze
- Highlights the visited frontier and the final shortest path
- Live visited-cell count and path length

## Getting started

```bash
npm install
npm run dev
```

Then open the printed local URL (default `http://localhost:5173`).

## Build for production

```bash
npm run build
npm run preview   # sanity-check the production build locally
```

The `dist/` folder is a fully static site — deploy it to Vercel, Netlify, or
GitHub Pages with zero configuration.

## Project structure

```
src/
  algorithms/
    sorting.js       # generator functions, one yielded frame per animation step
    pathfinding.js    # BFS/DFS/Dijkstra/A*, one yielded frame per visited cell
  components/
    SortingVisualizer.jsx
    GridVisualizer.jsx
    Controls.jsx       # shared play/pause/step/speed/reset bar
  App.jsx
  main.jsx
  index.css
```

Every algorithm is implemented as a JS generator that yields one animation
frame per "step" (a comparison, a swap, a visited node). The React components
just pull frames from the generator on an interval — the algorithm logic
itself has no knowledge of React, timing, or rendering, so it's easy to test
independently or reuse in a CLI/Node context.

## Why this design

- **Canvas over DOM nodes**: re-rendering 100+ styled `<div>`s every animation
  tick is the main perf bottleneck on low-end laptops. Canvas draws are a
  single imperative pass per frame.
- **Generators over recursion-with-callbacks**: lets "Step" and "Play" share
  the exact same code path (`generator.next()`), and makes it trivial to add
  a scrubber/rewind feature later if desired.
- **No backend**: everything is computed in-browser, so there's nothing to
  host, scale, or pay for — just a static bundle.

## Possible extensions

- Side-by-side comparison mode (run two algorithms on the same input at once)
- Big-O complexity readout that updates live as size changes
- Weighted-edge grid (currently uniform-cost, unit-weight grid)
- Export a run as a shareable GIF
